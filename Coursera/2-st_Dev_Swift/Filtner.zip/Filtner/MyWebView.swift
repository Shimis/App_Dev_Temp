//
//  MyWebView.swift
//  Filetener
//
//  Created by Alexander Larionov on 14.12.15.
//  Copyright © 2015 Alexander Larionov. All rights reserved.
//

import UIKit
import WebKit

class MyWebView: WKWebView {

    init(frame: CGRect, configuration: WKWebViewConfiguration) {
        <#code#>
    }
    
    
}
